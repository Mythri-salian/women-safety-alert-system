import { ShieldCheck } from "lucide-react";

const safetyTips = [
    {
        title: "Be Aware of Surroundings",
        description:
            "Avoid distractions like your phone when walking alone. Pay attention to people and paths.",
    },
    {
        title: "Trust Your Instincts",
        description:
            "If a situation or a person feels unsafe, remove yourself from the situation immediately.",
    },
    {
        title: "Share Your Plans",
        description:
            "Let a trusted friend or family member know your destination and expected arrival time.",
    },
    {
        title: "Walk in Well-Lit Areas",
        description:
            "Stick to populated and well-lit streets, especially at night. Avoid shortcuts through dark alleys.",
    },
    {
        title: "Have Your Keys Ready",
        description:
            "Don't fumble for keys at your car or front door. Be ready to enter quickly and lock up.",
    },
    {
        title: "Learn Basic Self-Defense",
        description:
            "Knowing a few basic techniques can build confidence and help you in a critical moment.",
    },
];

export default function SafetyTipsPage() {
    return (
        <main className="flex-1">
            <section id="safety-tips" className="py-16 md:py-24">
                <div className="container">
                    <h1 className="font-headline text-3xl md:text-4xl font-bold text-center mb-12">
                        Essential Safety Tips
                    </h1>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {safetyTips.map((tip) => (
                            <div key={tip.title} className="flex items-start space-x-4">
                                <ShieldCheck className="h-6 w-6 text-accent mt-1 shrink-0" />
                                <div>
                                    <h3 className="font-semibold text-lg">{tip.title}</h3>
                                    <p className="text-muted-foreground">{tip.description}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </main>
    );
}
