"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Send } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";

export default function LocationFetchedPage() {
    const router = useRouter();
    const [locationInput, setLocationInput] = useState("");
    const [isSubmitted, setIsSubmitted] = useState(false);

    const handleSubmit = () => {
        if (locationInput.trim() === "") return;
        setIsSubmitted(true);
        // Automatically redirect to the next step after a short delay
        setTimeout(() => {
            router.push('/inbox');
        }, 2000);
    };

    return (
        <main className="flex-1 flex items-center justify-center bg-accent/10">
            <Card className="w-full max-w-lg text-center animate-in fade-in-50 zoom-in-95">
                <CardHeader>
                    <div className="mx-auto bg-accent/20 text-accent p-4 rounded-full mb-4">
                        <MapPin className="h-12 w-12" />
                    </div>
                    <CardTitle className="text-3xl font-bold text-accent-foreground">
                        Step 3: Enter Your Location
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {!isSubmitted ? (
                        <>
                            <p className="text-muted-foreground text-lg mb-6">
                                Please enter your current location to help responders find you.
                            </p>
                            <Textarea
                                placeholder="e.g., 'Central Park, near the fountain' or 'Library, 2nd floor study area'"
                                value={locationInput}
                                onChange={(e) => setLocationInput(e.target.value)}
                                className="mb-4"
                                rows={3}
                            />
                            <Button onClick={handleSubmit} size="lg" disabled={!locationInput.trim()}>
                                Proceed to Next Step
                            </Button>
                        </>
                    ) : (
                        <div className="text-center space-y-3 animate-in fade-in-50">
                            <h3 className="text-xl font-bold">Location Noted:</h3>
                            <p className="text-lg bg-accent/10 p-3 rounded-md">"{locationInput}"</p>
                            <p className="text-sm text-muted-foreground pt-4">
                                Redirecting to the next step to send your message...
                            </p>
                        </div>
                    )}
                </CardContent>
            </Card>
        </main>
    );
}
