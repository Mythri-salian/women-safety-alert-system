import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Siren, Users, Zap } from "lucide-react";

export default function FeaturesPage() {
    return (
        <main className="flex-1">
            <section id="features" className="py-16 md:py-24">
                <div className="container text-center">
                    <h1 className="font-headline text-3xl md:text-4xl font-bold mb-12">
                        Core Features for Your Protection
                    </h1>
                    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
                        <Card className="text-center hover:shadow-lg transition-shadow">
                            <CardHeader className="items-center">
                                <div className="bg-accent/10 text-accent p-3 rounded-full">
                                    <Siren className="h-8 w-8" />
                                </div>
                                <CardTitle className="font-headline text-xl mt-2">
                                    Emergency Alert
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-muted-foreground">
                                    One-tap alert for immediate danger notification to your
                                    network.
                                </p>
                            </CardContent>
                        </Card>
                        <Card className="text-center hover:shadow-lg transition-shadow">
                            <CardHeader className="items-center">
                                <div className="bg-accent/10 text-accent p-3 rounded-full">
                                    <MapPin className="h-8 w-8" />
                                </div>
                                <CardTitle className="font-headline text-xl mt-2">
                                    Location Sharing
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-muted-foreground">
                                    Real-time GPS tracking sent to responders and trusted
                                    contacts.
                                </p>
                            </CardContent>
                        </Card>
                        <Card className="text-center hover:shadow-lg transition-shadow">
                            <CardHeader className="items-center">
                                <div className="bg-accent/10 text-accent p-3 rounded-full">
                                    <Users className="h-8 w-8" />
                                </div>
                                <CardTitle className="font-headline text-xl mt-2">
                                    Trusted Contacts
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-muted-foreground">
                                    Notify pre-selected friends and family members instantly.
                                </p>
                            </CardContent>
                        </Card>
                        <Card className="text-center hover:shadow-lg transition-shadow">
                            <CardHeader className="items-center">
                                <div className="bg-accent/10 text-accent p-3 rounded-full">
                                    <Zap className="h-8 w-8" />
                                </div>
                                <CardTitle className="font-headline text-xl mt-2">
                                    Quick Access
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-muted-foreground">
                                    Accessible via a simple home screen widget or physical button.
                                </p>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </section>
        </main>
    );
}
