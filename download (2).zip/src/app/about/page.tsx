import Image from "next/image";

export default function AboutPage() {
    return (
        <main className="flex-1">
            <section id="about" className="py-16 md:py-24">
                <div className="container">
                    <div className="grid md:grid-cols-2 gap-12 items-center">
                        <div className="flex justify-center items-center">
                            <Image
                                src="https://picsum.photos/seed/103/600/400"
                                alt="Community support"
                                width={600}
                                height={400}
                                className="rounded-lg shadow-xl"
                                data-ai-hint="community support"
                            />
                        </div>
                        <div>
                            <h1 className="font-headline text-3xl md:text-4xl font-bold mb-4">
                                About Our Project
                            </h1>
                            <p className="text-muted-foreground text-lg mb-4">
                                The Women Safety Alert System is a concept developed for college and hackathon demonstrations. It aims to showcase a technological solution to a pressing social issue: the safety of women.
                            </p>
                            <h2 className="font-headline text-2xl font-bold mt-6 mb-2">
                                Purpose & Social Impact
                            </h2>
                            <p className="text-muted-foreground text-lg">
                                Our primary goal is to raise awareness and inspire the development of real-world applications that can make a tangible difference. By simulating a rapid alert system, we highlight the potential for technology to empower individuals and connect them to help in critical moments. We believe that through innovation and community effort, we can build a safer environment for everyone.
                            </p>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    );
}
