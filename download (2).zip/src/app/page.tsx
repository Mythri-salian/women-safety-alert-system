"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <main className="flex-1 bg-yellow-100">
      {/* Hero Section */}
      <section
        id="hero"
        className="container flex flex-col items-center justify-center text-center py-20 md:py-32"
      >
        <h1 className="font-headline text-4xl md:text-6xl font-bold tracking-tighter mb-4">
          Women Safety Alert System
        </h1>
        <p className="max-w-[700px] text-lg text-muted-foreground mb-12">
          In an emergency, every second counts. Our system ensures you get
          help instantly.
        </p>
        <div className="relative flex flex-col items-center">
          <Link href="/emergency-alert" passHref>
            <Button
              size="lg"
              className="relative rounded-full h-40 w-40 text-3xl font-bold bg-red-500 hover:bg-red-600 text-white shadow-2xl transition-transform duration-300 ease-in-out hover:scale-105 active:scale-95 z-10"
              aria-label="Activate SOS Alert"
            >
              SOS
            </Button>
          </Link>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-52 w-52 rounded-full bg-red-500/30 animate-ping"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-72 w-72 rounded-full bg-red-500/20 animate-ping [animation-delay:0.5s]"></div>
        </div>
      </section>
    </main>
  );
}
