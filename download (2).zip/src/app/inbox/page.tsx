"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Send, CheckCircle, MessageSquare } from "lucide-react";
import Link from "next/link";


export default function InboxPage() {
  const [message, setMessage] = useState("");
  const [isSent, setIsSent] = useState(false);

  const handleSend = () => {
    if (message.trim() === "") return;
    setIsSent(true);
  };

  return (
    <main className="flex-1 flex items-center justify-center bg-gray-100 dark:bg-gray-900 p-4">
      <Card className="w-full max-w-lg animate-in fade-in-50 zoom-in-95">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <MessageSquare /> Step 4: Send Alert Message
          </CardTitle>
        </CardHeader>
        {!isSent ? (
          <>
            <CardContent>
              <Textarea
                placeholder="Type your emergency message here... e.g., 'I am in danger at the library, please hurry.'"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={4}
              />
            </CardContent>
            <CardFooter>
              <Button onClick={handleSend} className="w-full">
                <Send className="mr-2 h-4 w-4" /> Send Message
              </Button>
            </CardFooter>
          </>
        ) : (
          <CardContent className="text-center">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-xl font-bold">Your message is successfully sent.</h3>
            <p className="text-muted-foreground mt-2">
              Alert received by the system.
            </p>
            <Link href="/" passHref>
                <Button variant="outline" className="mt-6">Back to Home</Button>
            </Link>
          </CardContent>
        )}
      </Card>
    </main>
  );
}
