import { Card, CardContent } from "@/components/ui/card";
import { Phone } from "lucide-react";

const helplines = [
    { name: "National Emergency", number: "112" },
    { name: "Police", number: "100" },
    { name: "Women Helpline", number: "1091" },
    { name: "Ambulance", number: "102" },
];

export default function ContactPage() {
    return (
        <main className="flex-1">
            <section id="contact-help" className="py-16 md:py-24">
                <div className="container text-center">
                    <h1 className="font-headline text-3xl md:text-4xl font-bold mb-4">
                        Emergency? Get Help Now.
                    </h1>
                    <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
                        These helpline numbers are available for immediate assistance. Do
                        not hesitate to call if you are in danger.
                    </p>
                    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto">
                        {helplines.map((line) => (
                            <Card key={line.name} className="bg-card">
                                <CardContent className="p-4 flex flex-col items-center justify-center">
                                    <p className="text-muted-foreground text-sm">
                                        {line.name}
                                    </p>
                                    <a
                                        href={`tel:${line.number}`}
                                        className="font-headline text-2xl text-primary font-bold flex items-center gap-2 hover:underline"
                                    >
                                        <Phone className="h-5 w-5" /> {line.number}
                                    </a>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>
        </main>
    );
}
