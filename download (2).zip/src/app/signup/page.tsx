export default function SignupPage() {
  return null;
}
