import Image from "next/image";
import { ShieldCheck } from "lucide-react";

export default function ProblemPage() {
    return (
        <main className="flex-1">
            <section
                id="problem"
                className="py-16 md:py-24"
            >
                <div className="container">
                    <div className="grid md:grid-cols-2 gap-12 items-center">
                        <div>
                            <h1 className="font-headline text-3xl md:text-4xl font-bold mb-4">
                                The Challenge We Face
                            </h1>
                            <p className="text-muted-foreground text-lg mb-6">
                                Women often face safety threats, and delays in emergency
                                response can have severe consequences. Traditional methods of
                                calling for help can be slow and inefficient, especially when
                                under duress.
                            </p>
                            <ul className="space-y-3 text-muted-foreground">
                                <li className="flex items-center gap-3">
                                    <ShieldCheck className="h-5 w-5 text-primary shrink-0" />{" "}
                                    Difficulty in discreetly calling for help.
                                </li>
                                <li className="flex items-center gap-3">
                                    <ShieldCheck className="h-5 w-5 text-primary shrink-0" />{" "}
                                    Inaccurate location sharing with authorities.
                                </li>
                                <li className="flex items-center gap-3">
                                    <ShieldCheck className="h-5 w-5 text-primary shrink-0" />{" "}
                                    Delays in notifying trusted family or friends.
                                </li>
                            </ul>
                        </div>
                        <div className="flex justify-center items-center">
                            <Image
                                src="https://picsum.photos/seed/101/600/400"
                                alt="Woman looking concerned"
                                width={600}
                                height={400}
                                className="rounded-lg shadow-xl"
                                data-ai-hint="woman concerned"
                            />
                        </div>
                    </div>
                </div>
            </section>
        </main>
    );
}
