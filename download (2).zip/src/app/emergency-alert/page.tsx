"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BellRing, CheckCircle } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function EmergencyAlertPage() {
  const router = useRouter();
  const [showConfirmation, setShowConfirmation] = useState(true);

  return (
    <main className="flex-1 flex items-center justify-center bg-destructive/10">
      
      <Card className="w-full max-w-lg text-center animate-in fade-in-50 zoom-in-95">
        <CardHeader>
          <div className="mx-auto bg-destructive/20 text-destructive p-4 rounded-full mb-4 ring-8 ring-destructive/10 animate-pulse">
            <BellRing className="h-12 w-12" />
          </div>
          <CardTitle className="text-3xl font-bold text-destructive">
            Emergency Alert Activated
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-lg mb-6">
            A loud alert sound has been triggered to attract attention. This is a UI simulation.
          </p>
          <Button onClick={() => router.push('/alarm-triggered')} size="lg">
            Next: Trigger Public Alarm
          </Button>
        </CardContent>
      </Card>

      <AlertDialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <CheckCircle className="text-green-500 h-6 w-6" />
              Alert Sent to Trusted Contacts
            </AlertDialogTitle>
            <AlertDialogDescription>
              Your trusted contacts have been notified of your emergency.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={() => setShowConfirmation(false)}>
              Close
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </main>
  );
}
