"use client";

import Link from 'next/link';
import { Button } from "@/components/ui/button";
import { Radio, BellRing, MapPin, Send } from "lucide-react";

export default function HowItWorksPage() {
    return (
        <main className="flex-1">
            <section id="how-it-works" className="py-16 md:py-24">
                <div className="container text-center">
                    <h1 className="font-headline text-3xl md:text-4xl font-bold mb-12">
                        How It Works in an Emergency
                    </h1>
                    <div className="grid md:grid-cols-4 gap-8 max-w-5xl mx-auto mb-16">
                        <div className="flex flex-col items-center">
                            <div className="bg-primary/10 text-primary p-4 rounded-full mb-4 ring-8 ring-primary/5">
                                <Radio className="h-10 w-10" />
                            </div>
                            <h3 className="font-headline text-xl font-semibold mb-2">
                                1. Press SOS
                            </h3>
                            <p className="text-muted-foreground">
                                A single tap on the SOS button starts the emergency alert sequence.
                            </p>
                        </div>
                        <div className="flex flex-col items-center">
                            <div className="bg-primary/10 text-primary p-4 rounded-full mb-4 ring-8 ring-primary/5">
                                <BellRing className="h-10 w-10" />
                            </div>
                            <h3 className="font-headline text-xl font-semibold mb-2">
                                2. Alarm Triggered
                            </h3>
                            <p className="text-muted-foreground">
                                A loud public alarm is activated to alert nearby people for immediate help.
                            </p>
                        </div>
                        <div className="flex flex-col items-center">
                            <div className="bg-primary/10 text-primary p-4 rounded-full mb-4 ring-8 ring-primary/5">
                                <MapPin className="h-10 w-10" />
                            </div>
                            <h3 className="font-headline text-xl font-semibold mb-2">
                                3. Location Fetched
                            </h3>
                            <p className="text-muted-foreground">
                                Your live GPS location including city and state is fetched to guide helpers.
                            </p>
                        </div>
                        <div className="flex flex-col items-center">
                            <div className="bg-primary/10 text-primary p-4 rounded-full mb-4 ring-8 ring-primary/5">
                                <Send className="h-10 w-10" />
                            </div>
                            <h3 className="font-headline text-xl font-semibold mb-2">
                                4. Alert Sent
                            </h3>
                            <p className="text-muted-foreground">
                                An alert message is sent to your trusted contacts and emergency services via an inbox system.
                            </p>
                        </div>
                    </div>

                    <div className="max-w-2xl mx-auto bg-card p-6 rounded-lg border">
                        <h4 className="font-headline text-2xl font-bold mb-3">See the Flow in Action</h4>
                        <p className="text-muted-foreground mb-4">
                            Click the button below to walk through the emergency alert demonstration step-by-step.
                        </p>
                        <Link href="/emergency-alert" passHref>
                            <Button size="lg">
                                <BellRing className="mr-2 h-5 w-5" />
                                Demonstrate Alert Flow
                            </Button>
                        </Link>
                    </div>
                </div>
            </section>
        </main>
    );
}
