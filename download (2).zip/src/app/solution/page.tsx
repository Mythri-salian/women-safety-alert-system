import Image from "next/image";

export default function SolutionPage() {
    return (
        <main className="flex-1">
            <section
                id="solution"
                className="py-16 md:py-24"
            >
                <div className="container">
                    <div className="grid md:grid-cols-2 gap-12 items-center">
                        <div className="flex justify-center items-center md:order-last">
                            <Image
                                src="https://picsum.photos/seed/102/600/400"
                                alt="Woman feeling safe"
                                width={600}
                                height={400}
                                className="rounded-lg shadow-xl"
                                data-ai-hint="woman safe"
                            />
                        </div>
                        <div className="md:order-first">
                            <h1 className="font-headline text-3xl md:text-4xl font-bold mb-4">
                                A Reassuring Solution
                            </h1>
                            <p className="text-muted-foreground text-lg">
                                Our alert system is a rapid, reliable, and discreet way to
                                send out an emergency alert. With a single press, your
                                location is shared with trusted contacts and emergency
                                services, ensuring you get help when you need it most,
                                bridging the critical time gap.
                            </p>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    );
}
