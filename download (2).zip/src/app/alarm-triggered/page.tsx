"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Siren, Users, CheckCircle } from "lucide-react";

export default function AlarmTriggeredPage() {
  const router = useRouter();
  const [isTriggered, setIsTriggered] = useState(false);

  const handleTrigger = () => {
    setIsTriggered(true);
  };

  return (
    <main className="flex-1 flex items-center justify-center bg-primary/10">
      <Card className="w-full max-w-lg text-center animate-in fade-in-50 zoom-in-95">
        <CardHeader>
          <div className="mx-auto bg-primary/20 text-primary p-4 rounded-full mb-4">
            <Siren className="h-12 w-12" />
          </div>
          <CardTitle className="text-3xl font-bold text-primary">
            Step 2: Trigger Public Alarm
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!isTriggered ? (
            <>
              <p className="text-muted-foreground text-lg mb-6">
                Activate a public alarm to alert nearby people for immediate assistance.
              </p>
              <Button onClick={handleTrigger} size="lg">
                <Users className="mr-2" /> Trigger Alarm
              </Button>
            </>
          ) : (
            <div className="animate-in fade-in-50 text-center">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2">Public alarm activated.</h3>
              <p className="text-muted-foreground text-lg mb-6">
                Nearby people are alerted to help.
              </p>
              <Button onClick={() => router.push('/location-fetched')} size="lg">
                Next: Fetch Location
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
