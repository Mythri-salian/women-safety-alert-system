export const firebaseConfig = {
  "projectId": "studio-8721390727-9676a",
  "appId": "1:20982537832:web:05140f63821448281465dd",
  "apiKey": "AIzaSyA0sKcyv7B3iFYSKfE-uLf40psMXlGJ0m4",
  "authDomain": "studio-8721390727-9676a.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "20982537832"
};
